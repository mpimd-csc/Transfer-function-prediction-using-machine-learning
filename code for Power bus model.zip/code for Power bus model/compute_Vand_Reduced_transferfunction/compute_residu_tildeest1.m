
function [e,nr_rpr]=compute_residu_tildeest1(Vr,coeffV,coeffVr,coeffr,coeffrr,B,CVr,Br)

%---------------------------------------------------------
% compute e and e2 from the dual and the dual residual systems

xpr1=coeffr\Br;

rpr=B-coeffV*xpr1;
   


%  
xr=coeffrr\(Vr'*rpr);
% 
%e=abs(C*(Vr*xr));

e=abs(CVr*xr);
   
r_rpr=rpr-coeffVr*xr;

nr_rpr=norm(r_rpr);
       





