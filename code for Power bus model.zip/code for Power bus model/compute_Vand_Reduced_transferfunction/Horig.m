
clear all

time0=tic;

Main_Univaq_module_fun_ONCE;   

freqmin=1; freqmax=3e9; nfreq=400;
%freqv=linspace(freqmin,freqmax,nfreq);
freqv=logspace(log10(freqmin),log10(freqmax),nfreq);

s_sample=freqv'*sqrt(-1)*2*pi;

Ho=zeros(2,2,size(s_sample,1)); 


for i=1:size(s_sample,1)
    
    freq=freqv(i);
    
    Main_Univaq_module_fun;
    
    %coeff=Kmatrix;
    
    Ho(:,:,i)=C*(Kmatrix\B);
    
end

runtime=toc(time0);

save Horig Ho s_sample freqv runtime