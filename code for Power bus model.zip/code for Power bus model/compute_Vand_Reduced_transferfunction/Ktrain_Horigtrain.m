
clear all

time0=tic;

Main_Univaq_module_fun_ONCE;   

freqmin=1e5; freqmax=3e9; nfreq=30;
freqv=linspace(freqmin,freqmax,nfreq);

s_sample=freqv'*sqrt(-1)*2*pi;

K_train=cell(nfreq,1);

Horig_train=zeros(2,2,size(s_sample,1)); 

for i=1:nfreq
    
    freq=freqv(i);
    
    Main_Univaq_module_fun;
    
    K_train{i}=Kmatrix;
    
    Horig_train(:,:,i)=C*(Kmatrix\B);
    
end

runtime=toc(time0);

save Ktrain_Horigtrain_boxTL Horig_train K_train B C s_sample freqv runtime

% for k=1:10 K_train1{k}=K_train{k}; end
% for k=11:20 K_train2{k-10}=K_train{k}; end
% for k=21:30 K_train3{k-20}=K_train{k}; end
% 
% save Ktrain1 K_train1 B C s_sample freqv runtime
% save Ktrain2 K_train2 B C s_sample freqv runtime
% save Ktrain3 K_train3 B C s_sample freqv runtime