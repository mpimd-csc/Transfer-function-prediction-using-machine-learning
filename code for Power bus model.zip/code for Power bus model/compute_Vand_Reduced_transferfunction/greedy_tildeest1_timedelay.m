
function [index_max,index_2nd,merror,max_error_true]=greedy_tildeest1_timedelay(V,Vr,C,B,Numfreq,s_sample,expan_points,expan_points_2nd)
      
global coeff_K Horig_train

%=====================================================

error_true=sparse(Numfreq,1);

error_bound=error_true; error_bound_2nd=error_true;

ematrix=zeros(size(C,1),size(B,2));

Br=V'*B; Crr=C*Vr; Cr=C*V;

for i=1:size(s_sample,1)
       i
    %----------------------------
    %precompute coeffV and coeffVr, which are independent of the number of inputs and outputs.
     coeff = coeff_K{i};
     coeffV=coeff*V; coeffVr=coeff*Vr;
     % precompute some reduced quantities
     coeffr = V'*coeffV;
     coeffrr = Vr'*coeffVr;
    %-------------------------------------------
    
     for j=1:size(B,2)
        
        for k=1:size(C,1)
        
            
           [ematrix(k,j),e2(k,j)]=compute_residu_tildeest1(Vr,coeffV,coeffVr,coeffr,coeffrr,B(:,j),Crr(k,:),Br(:,j));  % compute the residuals corresponding to
           
                                                                              % mu.
        end
    end
                               
    %=================================================================
    % compute the error bound at sample(i) 
    
    %-----------------------------------------------
           
      Hr = Cr*(coeffr\Br);        % reduced transfer function % only for relative error
                                  % and for computing the true error
      Ho=Horig_train(:,:,i);
    %--------------------------------------------------------------
     mHr=max(max(abs(Hr))); 
     abm=abs(Ho-Hr);
     
     if mHr>=1
         %compute the relative error
         error_bound(i)=max(max(ematrix))/mHr;
         error_bound_2nd(i)=max(max(e2))/mHr;
         
         error_true(i)=max(max(abm))/mHr;  % relative true error, only for comparison, not compute in practice
      else
         %compute the absolute error bound 
         error_bound(i)=max(max(ematrix));  % absolute error bound
         error_bound_2nd(i)=max(max(e2));
             
         error_true(i)=max(max(abm)); % absolute true error, only for comparison, not compute in practice
      end
     
    %%=================================================================
  
end


error0=error_bound;

[merror,index_max]=max(error0);

s_max=s_sample(index_max);

smax_t=expan_points;  % smax stores all the selected expansion points.

fg=0;

sm=size(expan_points,1);

for j=1:sm
        
    if s_max==smax_t(j)
             
       error0(index_max)=0;
            
       smax_t(j)=[];
       
       fg=1;
       
       [merror_v,index_max]=max(error0);
           
       s_max=s_sample(index_max);
       
       break
       
    end
    
end

while ~isequal(smax_t,zeros(1,0)) && fg==1
    
     smt=size(smax_t,1);
     
     fg=0;
    
     for j=1:smt
        
         if s_max==smax_t(j)
             
            error0(index_max)=0;
            
            smax_t(j)=[];
            
            fg=1;
       
            [merror_v,index_max]=max(error0);
           
            s_max=s_sample(index_max);
            
            break
       
         end
     
     end
     
end

%-------------------------------------------------
% for e2, error_bound_2nd, 2nd part of the error estimation

error_2nd=error_bound_2nd;

[merror_2nd,index_2nd]=max(error_2nd);  %s_max=s_sample(index);

s_2nd=s_sample(index_2nd); 

smax_t=expan_points_2nd;  % smax stores all the selected expansion points.

fg=0;

sm=size(expan_points_2nd,1);

for j=1:sm
        
    if s_2nd==smax_t(j)
             
       error_2nd(index_2nd)=0;
            
       smax_t(j)=[];
       
       fg=1;
       
       [merror_2nd_v,index_2nd]=max(error_2nd);
           
       s_2nd=s_sample(index_2nd);
       
       break
       
    end
    
end

while ~isequal(smax_t,zeros(1,0)) && fg==1
    
     smt=size(smax_t,1);
     
     fg=0;
    
     for j=1:smt
        
         if s_2nd==smax_t(j)
             
            error_2nd(index_2nd)=0;
            
            smax_t(j)=[];
            
            fg=1;
       
            [merror_2nd_v,index_2nd]=max(error_2nd);
           
            s_2nd=s_sample(index_2nd);
            
            break
       
         end
     
     end
     
end



max_error_true=max(error_true);
         
  
            
    
