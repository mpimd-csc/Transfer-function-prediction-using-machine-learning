
clear all

 
time0=tic;

global coeff_K Horig_train

%------------------------------------------------------
%load PEEC_ground4mor freqv_train K_train B C

load Ktrain_Horigtrain_boxTL Horig_train K_train B C s_sample freqv


%------------------------------------------------------

coeff_K=K_train; clear K_train

Numfreq=size(freqv,2);  


tol=1e-3;  % the accuracy of the reduced model

epsilon=1;   % the maximal error bound for the samples in 
             % in the whole sample space: sigma_train
             % we initially assign epsilon with 1. 

V=[]; Vr=V;
 

expan_points=[]; expan_points_2nd=[];

error_true=[];  error_estimator_new=[]; 

err_alpha=[]; % check the accuracy of the eigenvalue computed by the projected matrix
              % V'*G*V in greedy_gLTI.m


%==================================================================
% define the whole sample space: sigma_train and
% stroe the samples into the vector: s_sample
% There are different ways of definition
 %minFrequency = 1e4;   % the range for the angular frequency \omega
 %maxFrequency = 5e8;

%s_sample=freqv'*sqrt(-1)*2*pi;

%-----------------------------------------------------
% End of defining the sample space for the train sample space

 
index_s=1; index_s2nd=Numfreq; 

while epsilon>tol

expan_points=[expan_points;s_sample(index_s)];  expan_points_2nd=[expan_points_2nd;s_sample(index_s2nd)];

coeff=coeff_K{index_s};    % selected expansion point s0=s;
 
Vs=coeff\B;

V=[V,real(Vs),imag(Vs)];

V=forthognalize(V,1e-7);

%------------------------------------------------------------
% Vr
   
   if size(expan_points,1)==1 
     
       coeff_pr=coeff_K{index_s2nd}; 
  
       Vprs=coeff_pr\B;
       
       Vr=[V,real(Vprs),imag(Vprs)];
       
       Vr=forthognalize(Vr,1e-7);   
       
   else
      if s_sample(index_s)~=s_sample(index_s2nd)
        
         coeff_pr=coeff_K{index_s2nd}; 
         
         Vprs=coeff_pr\B;
         
         Vr=[Vr,real(Vprs),imag(Vprs)];
      end
      
      Vr=[V,Vr];
      Vr=forthognalize(Vr,1e-7);
   end

      
%=====================================================


[index_s,index_s2nd,epsilon,max_error_true]=greedy_tildeest1_timedelay(V,Vr,C,B,Numfreq,s_sample,expan_points,expan_points_2nd); 


error_estimator_new=[error_estimator_new;epsilon]


error_true=[error_true;max_error_true]

%pause

end


time=toc(time0)



save redu_PEECBoxTL V time freqv s_sample expan_points expan_points_2nd tol error_estimator_new error_true 


