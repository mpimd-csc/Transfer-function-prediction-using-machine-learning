
Generate_K_B;
Kmatrix=full(K);
C=B.';




