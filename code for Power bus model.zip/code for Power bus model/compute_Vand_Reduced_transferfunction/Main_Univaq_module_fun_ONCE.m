
%load('PEEC_data_array_2x2');
load('PEEC_data_BoxTL');

% integration orders for non-orthogonal objects
order_integration_self_box=5; % for self and closer objects
order_integration_mutual_boxes=3; % for distant objects


% slow part to compute partial coefficients matrices (to run just once)
Compute_PEEC_dense_matrices;




