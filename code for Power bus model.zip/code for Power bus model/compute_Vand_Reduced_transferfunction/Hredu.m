
clear all

time0=tic;

freqmin=1; freqmax=3e9; nfreq=400;
%freqv=linspace(freqmin,freqmax,nfreq);
freqv=logspace(log10(freqmin),log10(freqmax),nfreq);

Main_Univaq_module_fun_ONCE;  

load redu_PEECBoxTL V 

Hr=zeros(2,2,nfreq);

%----------------------------------
% compute Hr at the first frequency sample
freq=freqv(1);
    
Main_Univaq_module_fun;

hatcoeff=V'*Kmatrix*V;

hatB=V'*B; hatC=C*V;
    
Hr(:,:,1)=hatC*(hatcoeff\hatB);
%-----------------------------------------------

%------------------------------------------------------
% compute Hr at the left frequency samples, but hatB and hatc need not
% computed, since they are independent of the frequency.

for i=2:nfreq
    
    freq=freqv(i);
    
    Main_Univaq_module_fun;
    
    hatcoeff=V'*Kmatrix*V;
        
    Hr(:,:,i)=hatC*(hatcoeff\hatB);
    
end
%--------------------------------------------------

runtime=toc(time0);

save Hredu Hr freqv runtime