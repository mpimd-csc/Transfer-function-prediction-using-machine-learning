
clear all

load Horig
%load Hredu

n=size(s_sample,1);

for i=1:n
    Ho11(i)=Ho(1,1,i);
    Ho13(i)=Ho(1,3,i);
    Ho14(i)=Ho(1,4,i);
    Ho15(i)=Ho(1,5,i);
    Ho22(i)=Ho(2,2,i);
    Ho23(i)=Ho(2,3,i);
    Ho24(i)=Ho(2,4,i);
    Ho25(i)=Ho(2,5,i);
    Ho21(i)=Ho(2,1,i);
    Ho16(i)=Ho(1,6,i);
    Ho34(i)=Ho(3,4,i);
    Ho55(i)=Ho(5,5,i);
    Ho44(i)=Ho(4,4,i);
    Ho45(i)=Ho(4,5,i);
    Ho33(i)=Ho(3,3,i);
    Ho35(i)=Ho(3,5,i);
    Ho26(i)=Ho(2,6,i);
    Ho36(i)=Ho(3,6,i);
    Ho46(i)=Ho(4,6,i);
    Ho56(i)=Ho(5,6,i);
    Ho66(i)=Ho(6,6,i);
end

save orig_fun_test_powerbus 