 clear all
% 
 load Hredu
% 
 n_train=200;
% 
 n_step=round(size(freqv,2)/n_train);
% 
 j=0;
% 
for i=1:n_step:size(freqv,2)
    
    j=j+1;
    
    Hr11(j)=Hr(1,1,i);
    Hr12(j)=Hr(1,2,i);
    Hr13(j)=Hr(1,3,i);
    Hr14(j)=Hr(1,4,i);
    Hr15(j)=Hr(1,5,i); 
    Hr16(j)=Hr(1,6,i);

    Hr21(j)=Hr(2,1,i);
    Hr22(j)=Hr(2,2,i);
    Hr23(j)=Hr(2,3,i);
    Hr24(j)=Hr(2,4,i);
    Hr25(j)=Hr(2,5,i);
    Hr26(j)=Hr(2,6,i);
    
    Hr31(j)=Hr(3,1,i);
    Hr32(j)=Hr(3,2,i);
    Hr33(j)=Hr(3,3,i);
    Hr34(j)=Hr(3,4,i);
    Hr35(j)=Hr(3,5,i);
    Hr36(j)=Hr(3,6,i);
    
    Hr41(j)=Hr(4,1,i);
    Hr42(j)=Hr(4,2,i);
    Hr43(j)=Hr(4,3,i);
    Hr44(j)=Hr(4,4,i);
    Hr45(j)=Hr(4,5,i);
    Hr46(j)=Hr(4,6,i);
    
    Hr51(j)=Hr(5,1,i);
    Hr52(j)=Hr(5,2,i);
    Hr53(j)=Hr(5,3,i);
    Hr54(j)=Hr(5,4,i);
    Hr55(j)=Hr(5,5,i);
    Hr56(j)=Hr(5,6,i);
    
    Hr61(j)=Hr(6,1,i);
    Hr62(j)=Hr(6,2,i);
    Hr63(j)=Hr(6,3,i);
    Hr64(j)=Hr(6,4,i);
    Hr65(j)=Hr(6,5,i);
    Hr66(j)=Hr(6,6,i);
    
    freqv_train(j)=freqv(i);
end
    
save redu_TFall_train200 


