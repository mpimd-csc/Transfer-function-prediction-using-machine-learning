clear all

load Horig

n_train=200;

n_step=round(size(freqv,2)/n_train);

j=0;

for i=1:n_step:size(freqv,2)
    
    j=j+1;
    
    Ho11_train(j)=Ho(1,1,i);
    Ho21_train(j)=Ho(2,1,i);
    Ho22_train(j)=Ho(2,2,i);
    freqv_train(j)=freqv(i);
end
    
save orig_TF_train200

% clear all
% 
% load Horig_BoxTL_2GHz
% 
% n_train=200;
% 
% n_step=1;
% 
% j=0;
% 
% for i=1:n_step:size(freqv,2)
%     
%     j=j+1;
%     
%     Ho11_train(j)=Horig_train(1,1,i);
%     Ho21_train(j)=Horig_train(2,1,i);
%     Ho22_train(j)=Horig_train(2,2,i);
%     freqv_train(j)=freqv(i);
% end
%     
% save orig_TF_train200