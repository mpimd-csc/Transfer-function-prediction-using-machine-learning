function Hr_RBF = RBF_Kr(Hr,s_sample,para_new)
    %11.05.2021: originally programmed by Sridhar, slightly modified by Lihong
    % Radial basis function interpolation
    % Consider function of the form:
    % Input : z -----> a vector of training samples of s
    %         Hr -----> reduced vector of transfer function V^TH(s)V at training samples of s.
     %        logHr----> logrithm of Hr.
    
    %       : Hr_RBF -----> (interpolated) reduced transfer function at new samples: para_new
    
   
    % Normalize parameter values to range [0 1]
        max_freq = max(s_sample);
        min_freq = min(s_sample);
        
        para_normalized = ( s_sample - repmat(min_freq,size(s_sample,1),1) )./ repmat(max_freq - min_freq, size(s_sample,1),1);
    
    z = para_normalized;
    %logHr = log10(Hr); 
     logHr=Hr;
     
    % Normalize new parameter samples to range [0 1]
        max_freq = max(para_new);
        min_freq = min(para_new);
        
        s_sample_new = (para_new - repmat(min_freq,size(para_new,1),1) )./ repmat(max_freq - min_freq, size(para_new,1),1);
    
    Hr_RBF = zeros(size(s_sample_new));
    
    rbf_funct = 'imq';
    
    % Define the radial basis function to be used
    
    if strcmp(rbf_funct,'gaussian')
        s   = 100; % Shape parameter for the RBF kernel
        rbf = @(r) exp(- (s * norm(r) ).^2) ; % Gaussian kernel
    else
        s   = 30; % Shape parameter for the RBF kernel
        rbf = @(r) 1./(1 + (s*norm(r)).^2); % Inverse Multiquadratic kernel
%         rbf = @(r) (norm(r).^2).*log(norm(r) + eps);
        %rbf = @(r) (norm(r).^2*log10(r));
    end
    
            ndata   = size(z,1);
            
            % Setup the RBF interpolant
            M = zeros(ndata,ndata);                             % the coefficient matrix M might be singular
            for i=1:ndata
                for j=1:i
                    r      = z(i) - z(j);
                    M(i,j) = rbf(r);
                    M(j,i) = M(i,j);
                end
            end

            npara = size(z,2);
            P     = [z ones(ndata,1)];               % H is the modified coefficient matrix, which sould be positive definite. 
            H     = [M   P
                     P'  zeros(npara+1,npara+1)];
            b     = [logHr ; zeros(npara+1 , 1) ];  
            
           
            w     = H\b;


            gamma   = w(1:ndata);
            omega   = w(ndata+1 : ndata+npara);
            omega0  = w(end);    

            rbf_interpolant = @(z1, omega0, omega, gamma, centers, ndata) omega0 + omega'*z1' + basis_rbf(z1,centers,ndata,gamma,rbf);


            % Interpolate using the RBF interpolant and get the
            % interpolated value at the new parameter sample 
            % 
            for k=1:length(Hr_RBF)
                %Hr_RBF(k) = 10.^(rbf_interpolant(s_sample_new(k), omega0, omega, gamma, z, ndata));
                Hr_RBF(k) = rbf_interpolant(s_sample_new(k), omega0, omega, gamma, z, ndata);
            end
            
                     
end
            