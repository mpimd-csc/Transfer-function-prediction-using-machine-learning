function summand = basis_rbf(z1,centers,ndata,gamma,rbf)
    summand = 0;
    for i=1:ndata
        r  = z1' - centers(i,:)';
        summand = summand + gamma(i)*rbf(r);
    end
end