
clear all

time0=tic;

%--------------------------------------------------
%load training data

%---------------------------------------------
%load reduced TF as training data

 load redu_TF_train200
 s_sample=freqv_train'*sqrt(-1)*2*pi;

%----------------------------------------------
% load original TF as training data
  
   
  %load orig_TF_train200 freqv_train Ho11_train
  %Hr11=Ho11_train; clear Ho11_train
 
 % end of loading training data
 %-------------------------------------------------


  Hr_real=real(Hr11');
  Hr_RBF_real = RBF_Kr(Hr_real,freqv_train',freqv');
  
 
  Hr_imag=imag(Hr11);
  Hr_RBF_imag = RBF_Kr(Hr_imag',freqv_train',freqv');
  
  Hr_RBF=Hr_RBF_real+Hr_RBF_imag*sqrt(-1); 
    
  hold on
 
  load orig_fun_test_powerbus Ho11
  
  figure(1)
  box on
  plot(freqv/1e9,angle(Ho11),'<b', 'MarkerSize',4);
  plot(freqv'/1e9,angle(Hr_RBF),'+r','MarkerSize',4);

  figure(2)
  hold on  
  plot(freqv/1e9,abs(Ho11),'b','LineWidth',1);
  plot(freqv'/1e9,abs(Hr_RBF),'--r','LineWidth',1);
  
  absHo=abs(Ho11);
  eH=abs(transpose(Ho11)-Hr_RBF)/max(absHo);
  eH11=eH;

  figure(3)
  plot(freqv'/1e9,eH,'b','LineWidth',1);
  
  
  time_end=toc(time0)

  Hr11_RBF=Hr_RBF;
  
  save error_redutrain200_timeRBF eH11 time_end Hr11_RBF
 
  % pause
  
  %-------------------------------------------------------------
  %============================================================
  clear all
    
  %------------------------------------------------------
  %--------------------------------------------------
  %load training data
  %---------------------------------------------
  %load reduced TF as training data
   load redu_TF_train200 
   
 % end of loading training data
 %-------------------------------------------------
 
  Hr_real=real(Hr21');
  Hr_RBF_real = RBF_Kr(Hr_real,freqv_train',freqv');
    
  Hr_imag=imag(Hr21);
  Hr_RBF_imag = RBF_Kr(Hr_imag',freqv_train',freqv');
  
  Hr_RBF=Hr_RBF_real+Hr_RBF_imag*sqrt(-1); 
  
  load orig_fun_test_powerbus Ho21
  

    figure(4)
    hold on   
    plot(freqv/1e9, angle(Ho21),'<b','MarkerSize',4);
    plot(freqv'/1e9,angle(Hr_RBF),'+r','MarkerSize',4);
    
   figure(5)
   hold on  
   plot(freqv/1e9,abs(Ho21),'b','LineWidth',1);
   plot(freqv'/1e9,abs(Hr_RBF),'--r','LineWidth',1);
   
   absHo=abs(Ho21);
   eH=abs(transpose(Ho21)-Hr_RBF)/max(absHo);
   eH21=eH;
  
   figure(6)
   plot(freqv'/1e9,eH,'b','LineWidth',1);

   Hr21_RBF=Hr_RBF;

   load error_redutrain200_timeRBF
   save error_redutrain200_timeRBF eH21 eH11 time_end Hr11_RBF Hr21_RBF
     
  %-------------------------------------------------------------

  %============================================================
  clear all
    
  %------------------------------------------------------
  %--------------------------------------------------
  %load training data
  %---------------------------------------------
  %load reduced TF as training data
   load redu_TF_train200 
   
 % end of loading training data
 %-------------------------------------------------
 
  Hr_real=real(Hr22');
  Hr_RBF_real = RBF_Kr(Hr_real,freqv_train',freqv');
    
  Hr_imag=imag(Hr22);
  Hr_RBF_imag = RBF_Kr(Hr_imag',freqv_train',freqv');
  
  Hr_RBF=Hr_RBF_real+Hr_RBF_imag*sqrt(-1); 
  
  load orig_fun_test_powerbus Ho22
  

    figure(7)
    hold on   
    plot(freqv/1e9, angle(Ho22),'<b','MarkerSize',4);
    plot(freqv'/1e9,angle(Hr_RBF),'+r','MarkerSize',4);
    
   figure(8)
   hold on  
   plot(freqv/1e9,abs(Ho22),'b','LineWidth',1);
   plot(freqv'/1e9,abs(Hr_RBF),'--r','LineWidth',1);
   
   absHo=abs(Ho22);
   eH=abs(transpose(Ho22)-Hr_RBF)/max(absHo);
   eH22=eH;
  
   figure(9)
   plot(freqv'/1e9,eH,'b','LineWidth',1);

   Hr22_RBF=Hr_RBF;

   load error_redutrain200_timeRBF
   save error_redutrain200_timeRBF eH22 eH21 eH11 time_end Hr11_RBF Hr21_RBF Hr22_RBF
     
  %-------------------------------------------------------------


  %============================================================
  clear all
    
  %------------------------------------------------------
  %--------------------------------------------------
  %load training data
  %---------------------------------------------
  %load reduced TF as training data
   load redu_TF_train200
  
 % end of loading training data
 %-------------------------------------------------
  Hr_real=real(Hr16');
  Hr_RBF_real = RBF_Kr(Hr_real,freqv_train',freqv');
  
  Hr_imag=imag(Hr16);
  Hr_RBF_imag = RBF_Kr(Hr_imag',freqv_train',freqv');
  
  Hr_RBF=Hr_RBF_real+Hr_RBF_imag*sqrt(-1); 
    
  
  load orig_fun_test_powerbus Ho16


   figure(10)
   hold on  
   plot(freqv/1e9,abs(Ho16),'b','LineWidth',1);
   plot(freqv'/1e9,abs(Hr_RBF),'--r','LineWidth',1);
   
   absHo=abs(Ho16);
   eH=abs(transpose(Ho16)-Hr_RBF)/max(absHo);
   eH16=eH;
   
   figure(11)
   plot(freqv'/1e9,eH,'b','LineWidth',1);
   
   figure(12)
   hold on   
   plot(freqv/1e9,angle(Ho16),'<b','MarkerSize',3);
   plot(freqv'/1e9,angle(Hr_RBF),'+r','MarkerSize',3);

   Hr16_RBF=Hr_RBF;
  
   load error_redutrain200_timeRBF
   save error_redutrain200_timeRBF eH16 eH21 eH22 eH11 time_end Hr16_RBF Hr11_RBF Hr21_RBF Hr22_RBF
  
  %============================================================
  clear all
    
  %------------------------------------------------------
  %--------------------------------------------------
  %load training data
  %---------------------------------------------
  %load reduced TF as training data
   load redu_TF_train200
  
 % end of loading training data
 %-------------------------------------------------
  Hr_real=real(Hr45');
  Hr_RBF_real = RBF_Kr(Hr_real,freqv_train',freqv');
  
  Hr_imag=imag(Hr45);
  Hr_RBF_imag = RBF_Kr(Hr_imag',freqv_train',freqv');
  
  Hr_RBF=Hr_RBF_real+Hr_RBF_imag*sqrt(-1); 
    
  
  load orig_fun_test_powerbus Ho45

   figure(13)
   hold on  
   plot(freqv/1e9,abs(Ho45),'b','LineWidth',1);
   plot(freqv'/1e9,abs(Hr_RBF),'--r','LineWidth',1);
   
   absHo=abs(Ho45);
   eH=abs(transpose(Ho45)-Hr_RBF)/max(absHo);
   eH45=eH;
   
   figure(14)
   plot(freqv'/1e9,eH,'b','LineWidth',1);
   
   figure(15)
   hold on   
   plot(freqv/1e9,angle(Ho45),'<b','MarkerSize',3);
   plot(freqv'/1e9,angle(Hr_RBF),'+r','MarkerSize',3);

   Hr45_RBF=Hr_RBF;
  
   load error_redutrain200_timeRBF
   save error_redutrain200_timeRBF eH16 eH45 eH21 eH22 eH11 time_end Hr16_RBF Hr11_RBF Hr21_RBF Hr22_RBF Hr45_RBF

   %============================================================
  clear all
    
  %------------------------------------------------------
  %--------------------------------------------------
  %load training data
  %---------------------------------------------
  %load reduced TF as training data
   load redu_TF_train200
  
 % end of loading training data
 %-------------------------------------------------
  Hr_real=real(Hr33');
  Hr_RBF_real = RBF_Kr(Hr_real,freqv_train',freqv');
  
  Hr_imag=imag(Hr33);
  Hr_RBF_imag = RBF_Kr(Hr_imag',freqv_train',freqv');
  
  Hr_RBF=Hr_RBF_real+Hr_RBF_imag*sqrt(-1); 
    
  
  load orig_fun_test_powerbus Ho33

   figure(16)
   hold on  
   plot(freqv/1e9,abs(Ho33),'b','LineWidth',1);
   plot(freqv'/1e9,abs(Hr_RBF),'--r','LineWidth',1);
   
   absHo=abs(Ho33);
   eH=abs(transpose(Ho33)-Hr_RBF)/max(absHo);
   eH33=eH;
   
   figure(17)
   plot(freqv'/1e9,eH,'b','LineWidth',1);
   
   figure(18)
   hold on   
   plot(freqv/1e9,angle(Ho33),'<b','MarkerSize',3);
   plot(freqv'/1e9,angle(Hr_RBF),'+r','MarkerSize',3);

   Hr33_RBF=Hr_RBF;
  
   load error_redutrain200_timeRBF
   save error_redutrain200_timeRBF eH33 eH16 eH45 eH21 eH22 eH11 time_end Hr16_RBF Hr11_RBF Hr21_RBF Hr22_RBF Hr45_RBF Hr33_RBF

   %============================================================
  clear all
    
  %------------------------------------------------------
  %--------------------------------------------------
  %load training data
  %---------------------------------------------
  %load reduced TF as training data
   load redu_TF_train200
  
 % end of loading training data
 %-------------------------------------------------
  Hr_real=real(Hr44');
  Hr_RBF_real = RBF_Kr(Hr_real,freqv_train',freqv');
  
  Hr_imag=imag(Hr44);
  Hr_RBF_imag = RBF_Kr(Hr_imag',freqv_train',freqv');
  
  Hr_RBF=Hr_RBF_real+Hr_RBF_imag*sqrt(-1); 
    
  
  load orig_fun_test_powerbus Ho44

   figure(19)
   hold on  
   plot(freqv/1e9,abs(Ho44),'b','LineWidth',1);
   plot(freqv'/1e9,abs(Hr_RBF),'--r','LineWidth',1);
   
   absHo=abs(Ho44);
   eH=abs(transpose(Ho44)-Hr_RBF)/max(absHo);
   eH44=eH;
   
   figure(20)
   plot(freqv'/1e9,eH,'b','LineWidth',1);
   
   figure(21)
   hold on   
   plot(freqv/1e9,angle(Ho44),'<b','MarkerSize',3);
   plot(freqv'/1e9,angle(Hr_RBF),'+r','MarkerSize',3);

   Hr44_RBF=Hr_RBF;
  
   load error_redutrain200_timeRBF
   save error_redutrain200_timeRBF eH33 eH44 eH16 eH45 eH21 eH22 eH11 time_end Hr16_RBF Hr11_RBF Hr21_RBF Hr22_RBF Hr45_RBF Hr33_RBF Hr44_RBF

